/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package team7api;
import java.util.ArrayList;
/**
 *
 * @author Laura
 * 
 * this class will create the average graph 
 * and the cards for each run
 */
public class AggregateRunData {
    
    public ArrayList avgData;
    public ArrayList runData;
    
    
    public void getAvgData(){
   /**
    *this method will go through all the runData, making multiple calls
    *get the average
    *save it to the arrayList avgData
    */
    }
    
    public void getGraph(ArrayList avgData){
   /**
    *this method will make the graph from avgData using some extended library
    */
    }
    
    
    
}
